package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	rand.Seed(time.Now().UnixNano()) // Inisialisasi generator bilangan acak

	for i := 1; i <= 5; i++ {
		go func(i int) {
			time.Sleep(time.Duration(rand.Intn(100)) * time.Millisecond) // Tambahkan delay acak
			fmt.Printf("Task A: %d\n", i)
		}(i)
	}

	for i := 1; i <= 5; i++ {
		go func(i int) {
			if i == 3 {
				time.Sleep(2 * time.Second) // Penundaan spesifik pada iterasi ke-3
			}
			time.Sleep(time.Duration(rand.Intn(100)) * time.Millisecond) // Tambahkan delay acak
			fmt.Printf("Task B: %d\n", i)
		}(i)
	}

	for i := 1; i <= 5; i++ {
		go func(i int) {
			time.Sleep(time.Duration(rand.Intn(100)) * time.Millisecond) // Tambahkan delay acak
			fmt.Printf("Task C: %d\n", i)
		}(i)
	}

	time.Sleep(5 * time.Second) // Crude way to wait for all goroutines to finish
}
